CONNECTION_THRESHOLD = 50
FAILED_ATTEMPT_THRESHOLD = 5
UNEXPECTED_PORTS = {21, 23, 2323}


def detect_intrusion(event):
    """
    Check one simulated network event.
    Return the event details and its detection result.
    """
    reasons = []

    connections = int(event.get("connections_per_minute", 0))
    failed_attempts = int(event.get("failed_attempts", 0))
    destination_port = int(event.get("destination_port", 0))

    if connections > CONNECTION_THRESHOLD:
        reasons.append(
            f"High connection rate: {connections} per minute"
        )

    if failed_attempts >= FAILED_ATTEMPT_THRESHOLD:
        reasons.append(
            f"Repeated failed attempts: {failed_attempts}"
        )

    if destination_port in UNEXPECTED_PORTS:
        reasons.append(
            f"Connection to a flagged port: {destination_port}"
        )

    result = event.copy()

    if reasons:
        result["status"] = "Suspicious"
        result["severity"] = "High"
    else:
        result["status"] = "Normal"
        result["severity"] = "Low"

    result["reasons"] = reasons
    return result


def analyse_traffic(events):
    """Analyse a list of simulated network events."""
    return [detect_intrusion(event) for event in events]
