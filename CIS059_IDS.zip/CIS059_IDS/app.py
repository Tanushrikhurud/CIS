
from flask import Flask, render_template_string, redirect, url_for
from detector import analyse_traffic
from simulator import generate_traffic, generate_random_event
from database import initialize_database, save_event, get_all_events

app = Flask(__name__)
initialize_database()

HTML_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>IoT Intrusion Detection System</title>

    <!-- Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f2f5fa;
            color: #202b3c;
        }

        header {
            background: #14243a;
            color: white;
            padding: 24px;
            text-align: center;
        }

        header p {
            color: #cbd5e1;
        }

        main {
            max-width: 1100px;
            margin: 25px auto;
            padding: 0 16px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
        }

        .card, .panel {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #14243a12;
            margin-bottom: 18px;
        }

        .number {
            font-size: 30px;
            font-weight: bold;
            margin-top: 8px;
        }

        button {
            border: 0;
            border-radius: 7px;
            padding: 11px 16px;
            background: #2563eb;
            color: white;
            font-weight: bold;
            cursor: pointer;
            margin: 4px 6px 12px 0;
        }

        button:hover {
            background: #1d4ed8;
        }

        .logs-button {
            display: inline-block;
            background: #15803d;
            color: white;
            padding: 11px 16px;
            border-radius: 7px;
            text-decoration: none;
            font-weight: bold;
        }

        .logs-button:hover {
            background: #166534;
        }

        .secondary {
            background: #475569;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 700px;
        }

        th, td {
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
        }

        th {
            background: #f8fafc;
        }

        .suspicious {
            color: #b91c1c;
            font-weight: bold;
        }

        .normal {
            color: #15803d;
            font-weight: bold;
        }

        .muted {
            color: #64748b;
            font-size: 14px;
        }

        .chart-container {
            position: relative;
            width: 100%;
            max-width: 600px;
            height: 300px;
            margin: 20px auto 0;
        }

        footer {
            text-align: center;
            padding: 20px;
            color: #64748b;
        }
    </style>
</head>

<body>

<header>
    <h1>IoT Intrusion Detection System</h1>
    <p>Lightweight Intrusion Detection for Constrained Node Networks</p>
</header>

<main>

    <!-- Dashboard Summary Cards -->
    <section class="cards">

        <div class="card">
            Total Events
            <div class="number">{{ total }}</div>
        </div>

        <div class="card">
            Normal Events
            <div class="number">{{ normal_count }}</div>
        </div>

        <div class="card">
            Suspicious Events
            <div class="number">{{ suspicious_count }}</div>
        </div>

    </section>

    <!-- Security Analytics Chart -->
    <section class="panel">
        <h2>Security Analytics</h2>
        <p class="muted">
            Overview of normal and suspicious simulated traffic events.
        </p>

        <div class="chart-container">
            <canvas id="securityChart"></canvas>
        </div>
    </section>

    <!-- Traffic Simulator -->
    <section class="panel">
        <h2>Traffic Simulator</h2>

        <p>
            <a href="/logs" class="logs-button">View Security Logs</a>
        </p>

        <p class="muted">
            This dashboard analyses simulated events, not live network traffic.
        </p>

        <form action="/refresh" method="post" style="display:inline;">
            <button type="submit">Load Sample Traffic</button>
        </form>

        <form action="/random" method="post" style="display:inline;">
            <button class="secondary" type="submit">
                Generate Random Event
            </button>
        </form>
    </section>

    <!-- Detection Results -->
    <section class="panel">
        <h2>Detection Results</h2>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Node</th>
                        <th>Connections/min</th>
                        <th>Port</th>
                        <th>Failed Attempts</th>
                        <th>Traffic Type</th>
                        <th>Status</th>
                        <th>Detection Reason</th>
                    </tr>
                </thead>

                <tbody>
                {% for event in events %}
                    <tr>
                        <td>{{ event.node_id }}</td>
                        <td>{{ event.connections_per_minute }}</td>
                        <td>{{ event.destination_port }}</td>
                        <td>{{ event.failed_attempts }}</td>
                        <td>{{ event.traffic_type }}</td>

                        <td class="{{ 'suspicious' if event.status == 'Suspicious' else 'normal' }}">
                            {{ event.status }}
                        </td>

                        <td>
                            {% if event.reasons %}
                                {{ event.reasons | join('; ') }}
                            {% else %}
                                No rule triggered
                            {% endif %}
                        </td>
                    </tr>

                {% else %}
                    <tr>
                        <td colspan="7">
                            No events yet. Load sample traffic to begin.
                        </td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
    </section>

</main>

<footer>
    Educational Prototype | Rule-Based Detection
</footer>

<!-- Draw the chart -->
<script>
    const normalCount = {{ normal_count | tojson }};
    const suspiciousCount = {{ suspicious_count | tojson }};

    const chartCanvas = document.getElementById("securityChart");

    new Chart(chartCanvas, {
        type: "doughnut",

        data: {
            labels: ["Normal Events", "Suspicious Events"],

            datasets: [{
                data: [normalCount, suspiciousCount],
                backgroundColor: ["#16a34a", "#dc2626"],
                borderColor: ["#ffffff", "#ffffff"],
                borderWidth: 3
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    position: "bottom"
                },

                tooltip: {
                    enabled: true
                }
            }
        }
    });
</script>

</body>
</html>
"""


events = analyse_traffic(generate_traffic())


@app.route("/")
def home():
    normal_count = sum(
        event["status"] == "Normal" for event in events
    )

    suspicious_count = sum(
        event["status"] == "Suspicious" for event in events
    )

    return render_template_string(
        HTML_PAGE,
        events=events,
        total=len(events),
        normal_count=normal_count,
        suspicious_count=suspicious_count,
    )


@app.route("/logs")
def logs():
    saved_events = get_all_events()

    logs_html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Security Logs</title>

        <style>
            body {
                font-family: Arial, sans-serif;
                background: #f2f5fa;
                padding: 25px;
                color: #202b3c;
            }

            h1 {
                color: #14243a;
            }

            a {
                color: #2563eb;
            }

            .table-wrap {
                overflow-x: auto;
            }

            table {
                width: 100%;
                background: white;
                border-collapse: collapse;
            }

            th, td {
                padding: 10px;
                border: 1px solid #ddd;
                text-align: left;
            }

            th {
                background: #14243a;
                color: white;
            }

            .suspicious {
                color: #b91c1c;
                font-weight: bold;
            }

            .normal {
                color: #15803d;
                font-weight: bold;
            }
        </style>
    </head>

    <body>
        <h1>Security Event Logs</h1>

        <p>Saved records: {{ events|length }}</p>

        <p><a href="/">Back to Dashboard</a></p>

        <div class="table-wrap">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Time</th>
                    <th>Node</th>
                    <th>Status</th>
                    <th>Severity</th>
                    <th>Detection Reason</th>
                </tr>

                {% for event in events %}
                <tr>
                    <td>{{ event.id }}</td>
                    <td>{{ event.created_at }}</td>
                    <td>{{ event.node_id }}</td>

                    <td class="{{ 'suspicious' if event.status == 'Suspicious' else 'normal' }}">
                        {{ event.status }}
                    </td>

                    <td>{{ event.severity }}</td>

                    <td>{{ event.reasons or 'No rule triggered' }}</td>
                </tr>

                {% else %}
                <tr>
                    <td colspan="6">No saved events yet.</td>
                </tr>
                {% endfor %}
            </table>
        </div>
    </body>
    </html>
    """

    return render_template_string(
        logs_html,
        events=saved_events
    )


@app.route("/refresh", methods=["POST"])
def refresh():
    global events

    events = analyse_traffic(generate_traffic())

    for event in events:
        save_event(event)

    return redirect(url_for("home"))


@app.route("/random", methods=["POST"])
def random_event():
    global events

    new_event = generate_random_event()
    analysed_event = analyse_traffic([new_event])[0]

    events.append(analysed_event)
    save_event(analysed_event)

    events = events[-100:]

    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run(debug=True)
