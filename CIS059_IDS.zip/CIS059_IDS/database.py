
import sqlite3

DATABASE_NAME = "ids.db"


def get_connection():
    connection = sqlite3.connect(DATABASE_NAME)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database():
    with get_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS security_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                node_id TEXT NOT NULL,
                connections_per_minute INTEGER NOT NULL,
                destination_port INTEGER NOT NULL,
                failed_attempts INTEGER NOT NULL,
                traffic_type TEXT NOT NULL,
                status TEXT NOT NULL,
                severity TEXT NOT NULL,
                reasons TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)


def save_event(event):
    reasons = "; ".join(event.get("reasons", []))

    with get_connection() as connection:
        connection.execute("""
            INSERT INTO security_events (
                node_id,
                connections_per_minute,
                destination_port,
                failed_attempts,
                traffic_type,
                status,
                severity,
                reasons
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event["node_id"],
            event["connections_per_minute"],
            event["destination_port"],
            event["failed_attempts"],
            event["traffic_type"],
            event["status"],
            event["severity"],
            reasons
        ))


def get_all_events():
    with get_connection() as connection:
        rows = connection.execute("""
            SELECT *
            FROM security_events
            ORDER BY id DESC
        """).fetchall()

    return [dict(row) for row in rows]
