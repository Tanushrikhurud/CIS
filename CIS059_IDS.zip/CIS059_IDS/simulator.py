
import random


def generate_traffic():
    """Generate normal and suspicious sample IoT events."""

    return [
        {
            "node_id": "IoT-001",
            "connections_per_minute": 12,
            "destination_port": 443,
            "failed_attempts": 0,
            "traffic_type": "Normal sensor update",
        },
        {
            "node_id": "IoT-002",
            "connections_per_minute": 85,
            "destination_port": 443,
            "failed_attempts": 1,
            "traffic_type": "High connection rate",
        },
        {
            "node_id": "IoT-003",
            "connections_per_minute": 10,
            "destination_port": 23,
            "failed_attempts": 0,
            "traffic_type": "Flagged destination port",
        },
        {
            "node_id": "IoT-004",
            "connections_per_minute": 15,
            "destination_port": 443,
            "failed_attempts": 7,
            "traffic_type": "Repeated failed attempts",
        },
    ]


def generate_random_event():
    """Generate one random simulated event for testing."""

    ports = [80, 443, 1883, 21, 23, 2323]

    return {
        "node_id": f"IoT-{random.randint(1, 20):03d}",
        "connections_per_minute": random.randint(1, 100),
        "destination_port": random.choice(ports),
        "failed_attempts": random.randint(0, 8),
        "traffic_type": "Random simulated event",
    }
